#!/bin/bash
#SBATCH --partition=applied
#SBATCH --output=/lustre/scratch/client/vinai/users/khoilm1/slurm_log/%x-%j.out
#SBATCH --error=/lustre/scratch/client/vinai/users/khoilm1/slurm_log/%x-%j.out
#SBATCH --job-name=kd
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-node=2
#SBATCH --cpus-per-task=64
#SBATCH --mem=128G
#SBATCH --mail-user=v.khoilm1@vinai.io
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL



srun --container-image=/lustre/scratch/client/vinai/users/khoilm1/setup/docker_images/aqlm_wd.sqsh \
     --container-mounts=/lustre/scratch/client/vinai/users/khoilm1/:/root/ \
     --container-workdir=/root/ \
     /bin/bash -c \
     "
     export HTTP_PROXY=http://proxytc.vingroup.net:9090/
     export HTTPS_PROXY=http://proxytc.vingroup.net:9090/
     export http_proxy=http://proxytc.vingroup.net:9090/
     export https_proxy=http://proxytc.vingroup.net:9090/

	 export TOKENIZERS_PARALLELISM=false
	 export HF_HOME=/root/.cache/huggingface

     cd /root

     cd research/llm_kd/aqlm/pretrain-aqlm
	 python distill.py
     "
