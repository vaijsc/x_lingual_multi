#!/bin/bash
#SBATCH --partition=applied
#SBATCH --output=/lustre/scratch/client/vinai/users/khoilm1/slurm_log/%x-%j.out
#SBATCH --error=/lustre/scratch/client/vinai/users/khoilm1/slurm_log/%x-%j.out
#SBATCH --job-name=kd
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gpus-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --mem=128G
#SBATCH --mail-user=v.khoilm1@vinai.io
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL
#SBATCH --exclude=sdc2-hpc-dgx-a100-001


srun --container-image=/lustre/scratch/client/vinai/users/khoilm1/setup/docker_images/aqlm_lm_eval.sqsh \
     --container-mounts=/lustre/scratch/client/vinai/users/khoilm1/:/root/ \
     --container-workdir=/root/ \
     /bin/bash -c \
     "
     export HTTP_PROXY=http://proxytc.vingroup.net:9090/
     export HTTPS_PROXY=http://proxytc.vingroup.net:9090/
     export http_proxy=http://proxytc.vingroup.net:9090/
     export https_proxy=http://proxytc.vingroup.net:9090/

     export TOKENIZERS_PARALLELISM=false
     export HF_HOME=/root/.cache/huggingface/
     export HF_DATASETS_CACHE=/root/.cache/huggingface/datasets/

     cd /root

     cd research/llm_kd/aqlm/pretrain-aqlm
     # lm-eval --model hf --model_args pretrained=ckpts/llama3_aqlm --tasks arc_challenge,hellaswag,piqa,winogrande --device cuda:0 --batch_size 4
     # lm-eval --model hf --model_args pretrained=ckpts/llama3_aqlm,peft=ckpts/pretrain/llama3/minipile_alpaca_auth_big_lr/epoch_3 --tasks arc_challenge,hellaswag,piqa,winogrande --device cuda:0 --batch_size 4
     # lm-eval --model hf --model_args pretrained=ckpts/llama3_aqlm,peft=ckpts/pretrain/llama3/slimapajama_alpaca/epoch_3 --tasks arc_challenge,hellaswag,piqa,winogrande --device cuda:0 --batch_size 4
     # lm-eval --model hf --model_args pretrained=ckpts/qwen2_1.5b --tasks arc_challenge,hellaswag,piqa,winogrande --device cuda:0 --batch_size 4
	lm-eval --model hf --model_args pretrained=ckpts/llama3_pv,peft=ckpts/pretrain/llama3_pv/alpaca_thought/epoch_4 --tasks arc_challenge,hellaswag,piqa,winogrande --device cuda:0 --batch_size 4
     "
